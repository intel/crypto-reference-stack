#!/bin/sh
set -x
autoreconf --force --install
