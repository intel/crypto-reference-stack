Lots of password lists available here:

	https://wiki.skullsecurity.org/Passwords

Various other sources. Licensing of some of these lists is questionable - however I believe
that these would reasonably fall under the 'list of facts' and 'can't copyright the phone
book' copyright scenarios. If someone objects to a list being included here, it will be
removed immediately.

Clarkson - Jim Owens and Jeanna Mathews research project
========================================================
http://people.clarkson.edu/~owensjp/pubs/leet08.pdf


Openwall word lists
===================

The following copyright statement applies to this wordlists collection
as a whole:

Copyright (c) 2002,2003 by Solar Designer of Openwall Project

The homepage URL for this wordlists collection is:

http://www.openwall.com/wordlists/

You're allowed to use and redistribute this wordlists collection or
parts thereof, with or without modification, provided that credit is
given where it is due, any modified versions are marked as such, this
license is kept intact and included with each copy, and NO FEE IS
CHARGED FOR OBTAINING A COPY except as negotiated with the copyright
holder.  In particular, you are NOT permitted to charge for bandwidth,
physical media, and/or shipping.  You're also not permitted to bundle
this wordlists collection with a product you charge for.

If redistribution for a fee is what you're after, please contact the
copyright holder to negotiate special terms for the downloadable or
the extended CD-ready version of this collection.

It was a significant amount of work to compile this collection and
having a monopoly on regulating the CD sales is my way to compensate
for the time already spent and to allow for further work.

-- 
Alexander Peslyak aka Solar Designer <solar at openwall.com>
GPG key ID: B35D3598  fp: 6429 0D7E F130 C13E C929  6447 73C3 A290 B35D 3598
http://www.openwall.com - bringing security into open computing environments