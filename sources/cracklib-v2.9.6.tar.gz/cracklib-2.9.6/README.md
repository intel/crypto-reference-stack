# cracklib
CrackLib Library and Dictionaries

  * src - Cracklib distribution itself
  * words - scripts and content to build a full size password dictionary
