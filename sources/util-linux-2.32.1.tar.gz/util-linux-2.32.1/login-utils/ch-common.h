#ifndef UTIL_LINUX_CH_COMMON_H
#define UTIL_LINUX_CH_COMMON_H

extern int illegal_passwd_chars(const char *str);

#endif	/* UTIL_LINUX_CH_COMMON */
