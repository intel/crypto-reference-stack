#ifndef LR_TEST_REPOMD_H
#define LR_TEST_REPOMD_H

#include <check.h>

Suite *repomd_suite(void);

#endif
