#ifndef LR_TEST_URL_SUBSTITUTION_H
#define LR_TEST_URL_SUBSTITUTION_H

#include <check.h>

Suite *url_substitution_suite(void);

#endif
