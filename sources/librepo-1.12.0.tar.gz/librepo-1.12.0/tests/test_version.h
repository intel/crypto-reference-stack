#ifndef LR_TEST_VERSION_H
#define LR_TEST_VERSION_H

#include <check.h>

Suite *version_suite(void);

#endif
