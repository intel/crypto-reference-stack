#ifndef LR_TEST_REPO_ZCK_H
#define LR_TEST_REPO_ZCK_H

#include <check.h>

Suite *repo_zck_suite(void);

#endif
