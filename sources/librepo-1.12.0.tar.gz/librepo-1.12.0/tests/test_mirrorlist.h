#ifndef LR_TEST_MIRRORLIST_H
#define LR_TEST_MIRRORLIST_H

#include <check.h>

Suite *mirrorlist_suite(void);

#endif
