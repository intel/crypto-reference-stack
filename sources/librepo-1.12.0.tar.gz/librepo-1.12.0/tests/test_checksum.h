#ifndef LR_TEST_CHECKSUM_H
#define LR_TEST_CHECKSUM_H

#include <check.h>

Suite *checksum_suite(void);

#endif
