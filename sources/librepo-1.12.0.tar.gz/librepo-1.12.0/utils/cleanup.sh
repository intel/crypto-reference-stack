#!/bin/bash

rm -f librepo-*.tar.gz librepo-*.rpm python2-librepo-*.rpm python-librepo-*.rpm python3-librepo-*.rpm
echo -e "Done"
