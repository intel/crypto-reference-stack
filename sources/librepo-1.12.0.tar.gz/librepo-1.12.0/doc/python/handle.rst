.. _handle:

Handle (librepo.Handle)
=======================

.. autoclass:: librepo.Handle
   :members: