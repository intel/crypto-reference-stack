.. _result:

Result (librepo.Result)
=======================

.. autoclass:: librepo.Result
   :members: