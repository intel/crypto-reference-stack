#######
librepo
#######

A library providing C and Python (libcURL like) API for downloading linux repository metadata and packages

Contents:

.. toctree::
   :maxdepth: 2
   
   lib
   examples


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

