#!/bin/bash

pushd `dirname $0`
PYTHONPATH="../build/librepo/python/python2/" lettuce
popd
