.. GPGME Python Bindings documentation master file, created by
   sphinx-quickstart on Wed Dec  5 09:04:47 2018.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

GPGME Python Bindings
=====================

.. toctree::
   :maxdepth: 3
   :caption: Contents:

Contents
--------

-  `A short history of the project <short-history>`__
-  `What\'s New <what-is-new>`__

   -  `Maintenance Mode <maintenance-mode>`__ (from January, 2019)

-  `What Was New <what-was-new>`__
-  `GPGME Python Bindings HOWTO <gpgme-python-howto>`__
